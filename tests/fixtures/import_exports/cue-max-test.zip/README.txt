top level non-cue
